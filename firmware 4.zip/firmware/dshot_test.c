/*
 * dshot_test.c — bring-up main, now driving motors via plain 50 Hz servo
 * PWM (not DShot). The dshot.c driver is still compiled but unused; you
 * can exclude it from the build to save ~220 B of RAM if you want a
 * cleaner image, but it does no harm staying.
 *
 * Sequence:
 *   - For ARM_HOLD_SECONDS the firmware drives 1000 µs (idle) on all
 *     four motors so each ESC auto-detect locks onto PWM and arms.
 *   - After the arm hold, all four motors get SPIN_PULSE_US and stay
 *     there until power-off.
 *
 * BEFORE TESTING:
 *   - Disconnect ESC battery, wait ~5 seconds, reconnect. ESCs latch
 *     onto input protocol on power-up; they need a fresh boot to
 *     auto-detect PWM (you've been running DShot at them so they're
 *     currently in DShot mode).
 *   - Listen for arming tones — usually a single long beep then a
 *     descending 2-note pair, different from DShot's rising chime.
 *   - Hands clear. Airframe restrained.
 *
 * SWD WATCH:
 *   - tick_count_10khz / boot_seconds: scheduler tick. Should climb.
 *   - TIMA1->COUNTERREGS.CC_01[0]: CC value for Motor 1. Equals
 *     PWM_LOAD - (pulse_us * 2). 37999 = 1000 µs (idle). 35199 =
 *     1400 µs (current SPIN_PULSE_US).
 */

#include <ti/devices/msp/msp.h>
#include <stdint.h>
#include <stdbool.h>
#include "pwm.h"
#include "delay.h"

volatile uint32_t tick_count_10khz = 0;
volatile uint32_t boot_seconds     = 0;

#define TIMG0_PREDIV       (8u)
#define TIMG0_RELOAD       (200u)

/* Arming: ARM_HOLD_SECONDS of 1000 µs idle, then SPIN_PULSE_US.
 * 5 seconds gives BLHeli's PWM auto-detect plenty of margin. */
#define ARM_HOLD_SECONDS   (5u)
#define ARM_HOLD_TICKS     (ARM_HOLD_SECONDS * 10000u)
#define SPIN_PULSE_US      (1400u)  /* 1000=idle, 2000=full; 1400 ~ 40 %.
                                     * High enough to clearly break the
                                     * cogging-torque threshold for an
                                     * 11000 KV motor; low enough to be
                                     * safe on the bench. Bump higher
                                     * (1600, 1800) if still no spin. */

static void ConfigureClocks(void)
{
    SYSCTL->SOCLOCK.MCLKCFG =
        (1u << SYSCTL_MCLKCFG_MDIV_OFS) | SYSCTL_MCLKCFG_UDIV_DIVIDE2;
    delay_cycles(POWER_STARTUP_DELAY * 4);
}

static void InitializeTimerG0_OnMCLK(void)
{
    TIMG0->GPRCM.RSTCTL = (GPTIMER_RSTCTL_KEY_UNLOCK_W
                           | GPTIMER_RSTCTL_RESETSTKYCLR_CLR
                           | GPTIMER_RSTCTL_RESETASSERT_ASSERT);
    TIMG0->GPRCM.PWREN  = (GPTIMER_PWREN_KEY_UNLOCK_W
                           | GPTIMER_PWREN_ENABLE_ENABLE);
    delay_cycles(POWER_STARTUP_DELAY);

    TIMG0->CLKSEL                  = GPTIMER_CLKSEL_BUSCLK_SEL_ENABLE;
    TIMG0->CLKDIV                  = (TIMG0_PREDIV - 1u);
    TIMG0->COUNTERREGS.LOAD        = (TIMG0_RELOAD - 1u);
    TIMG0->COUNTERREGS.CTRCTL      = GPTIMER_CTRCTL_REPEAT_REPEAT_1;
    TIMG0->CPU_INT.IMASK           = GPTIMER_CPU_INT_IMASK_Z_SET;
    TIMG0->COMMONREGS.CCLKCTL      = GPTIMER_CCLKCTL_CLKEN_ENABLED;

    NVIC_EnableIRQ(TIMG0_INT_IRQn);
    TIMG0->COUNTERREGS.CTRCTL |= GPTIMER_CTRCTL_EN_ENABLED;
}

void TIMG0_IRQHandler(void)
{
    switch (TIMG0->CPU_INT.IIDX) {
        case GPTIMER_CPU_INT_IIDX_STAT_Z:
            tick_count_10khz++;
            if ((tick_count_10khz % 10000u) == 0u) {
                boot_seconds++;
            }
            /* No frame-by-frame transmit step for PWM — the timer is
             * always emitting whatever pulse width its CC currently
             * encodes. We only touch the staged value once at boot
             * (idle) and once when the arm hold expires (spin). */
            if (tick_count_10khz == 1u) {
                pwm_set_all_min();
            } else if (tick_count_10khz == ARM_HOLD_TICKS) {
                pwm_set_value(PWM_MOTOR_1, SPIN_PULSE_US);
                pwm_set_value(PWM_MOTOR_2, SPIN_PULSE_US);
                pwm_set_value(PWM_MOTOR_3, SPIN_PULSE_US);
                pwm_set_value(PWM_MOTOR_4, SPIN_PULSE_US);
            }
            break;
        default:
            break;
    }
}

int main(void)
{
    ConfigureClocks();
    pwm_init();                  /* timers come up driving 1000 µs idle */
    InitializeTimerG0_OnMCLK();  /* 10 kHz scheduler tick */

    __enable_irq();

    for (;;) {
        __WFI();
    }
}
